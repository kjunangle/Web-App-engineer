<?php
/* @var $this MovieBlogController */

$this->breadcrumbs=array(
	'Movie Now Showing',
);
?>
<h1><?php echo $this->id . '/' . $this->action->id; ?></h1>
<table>
    
    <thead>
    <th>ID</th>
    <th>#</th>
      <th>Name</th>
    </thead>
    
    <tbody id="tbody">
        <tr></tr><tr></tr>
        
    </tbody>
</table>

<p> </p>
 

<div>
              
                <div id="pagination">                   
                </div>
            </div>