<?php
/* @var $this MovieBlogController */

$this->breadcrumbs=array(
	'Movie Details',
);

?>
<h1><?php echo $this->id . '/' . $this->action->id; ?></h1>

<table>
    
    <thead>
    <th>ID</th>
    <th>#</th>
      <th>Name</th>
          <th>overview</th>
          
         <th> production_companies</th>
          <th> popularity</th>
           <th>Vote Average</th>
    </thead>
    
    <tbody id="tbody">
         
        
    </tbody>
    </table>
    <div id="digg">
         
        
    </div>
