<?php
/* @var $this MovieBlogController */

$this->breadcrumbs=array(
	'Movie Now Showing',
);
?>
<div class="jumbotron"><center><div class="hdcolor"><h1 class="hdcolor">Now Showing</h1></div></center></div>
<div class="container">
    <div id="tbody">
        
        
    </div>

</div>