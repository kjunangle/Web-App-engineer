<?php
/* @var $this MovieBlogController */

$this->breadcrumbs=array(
	'Movie Blog',
);
?>
<div class ="jumbotron"><center><div class="hdcolor"><h1 >Movies</h1></div></center></div>
<div class="container">
    <div id="tbody">
        
        
    </div>

</div>