<?php
/* @var $this MovieBlogController */

$this->breadcrumbs=array(
	'Movie Upcoming',
);
?>
<div class="jumbotron"><center><div class="hdcolor"><h1 >Coming SOON</h1></div></center></div>
<div class="container">
    <div id="tbody">
        
        
    </div>

</div>