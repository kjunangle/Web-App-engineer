<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name;
?>
<style>


.right{
   text-align: right;
} 
</style> 
  
        
        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
 

 
<!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">

    
  </div>

  <!-- Controls -->
  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
      


  <!-- Page Content -->
    <div class="container">

        <!-- Coming soon -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <a href="movieblog/upcoming">Coming soon </a>
                </h1>
            </div>
            <div id="tbody2">
                
                
                
            </div>
            <!-- <div class="col-md-3">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4><i class="fa fa-fw fa-check"></i> IRON MAN 12 </h4>
                    </div>
                    <div class="panel-body">
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Itaque, optio corporis quae nulla aspernatur in alias at numquam rerum ea excepturi expedita tenetur assumenda voluptatibus eveniet incidunt dicta nostrum quod?</p>
                        <a href="#" class="btn btn-default">View more</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4><i class="fa fa-fw fa-gift"></i> ANT MAN </h4>
                    </div>
                    <div class="panel-body">
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Itaque, optio corporis quae nulla aspernatur in alias at numquam rerum ea excepturi expedita tenetur assumenda voluptatibus eveniet incidunt dicta nostrum quod?</p>
                        <a href="#" class="btn btn-default">View more</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4><i class="fa fa-fw fa-compass"></i>MINNIONS</h4>
                    </div>
                    <div class="panel-body">
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Itaque, optio corporis quae nulla aspernatur in alias at numquam rerum ea excepturi expedita tenetur assumenda voluptatibus eveniet incidunt dicta nostrum quod?</p>
                        <a href="#" class="btn btn-default">View more</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4><i class="fa fa-fw fa-compass"></i>MINNIONS</h4>
                    </div>
                    <div class="panel-body">
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Itaque, optio corporis quae nulla aspernatur in alias at numquam rerum ea excepturi expedita tenetur assumenda voluptatibus eveniet incidunt dicta nostrum quod?</p>
                        <a href="#" class="btn btn-default">View more</a>
                    </div>
                </div>
            </div> -->
        </div>
        <!-- /.row -->

        <!-- Movie review -->
        <div class="row">
            <div class="col-lg-8">
                <div class="page-header">
                    <h2>New Review</h2>
                    
                </div>
               
                

                <div class="col-md-4">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4><i class="fa fa-fw fa-compass"></i></h4>
                        </div>
                        <div class="panel-body">
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Itaque, optio corporis quae nulla aspernatur in alias at numquam rerum ea excepturi expedita tenetur assumenda voluptatibus eveniet incidunt dicta nostrum quod?</p>
                            <a href="#" class="btn btn-default">View more</a>
                        </div>
                    </div>
                </div> 
                
       
                
                
                
            </div>
            <div class ="col-lg-4 col-md-4">
                <h2 class="page-header">Box Office</h2>
                
                <div class="box">
                    <div class="thai"><h4>THAI</h4>
                    <div class="row">
                        
                        <div class="col-md-5"><b>Title</b></div>
                        <div class="col-md-4"><b>This Week</b></div>
                        <div class="col-md-3"><b>Total</b></div>
                    </div>
                    
                    </div>
                    <div class="usa"></n><h4>USA</h4>
                    <div class="row">
                        
                        <div class="col-md-5"><b>Title</b></div>
                        <div class="col-md-4"><b>This Week</b></div>
                        <div class="col-md-3"><b>Total</b></div>
                    </div>
                    
                    </div>
                </div>
            </div>
        </div>
        <!-- /.row -->

        <!-- News -->
        <div class="row">
            <div class="col-lg-8">
                <h2 class="page-header"><a href="#">Movie News</a></h2>
            </div>
            <div class="col-md-8">
                <div class="panel panel-default">
                <div class="panel-heading"> <span class="glyphicon glyphicon-list-alt"></span></div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-xs-12">
                            <ul class="demo">

                            

                            

                    

                        </ul>
                        </div>
                        </div>
                        </div>
                        <div class="panel-footer"> </div>
                        </div>
                        </div>
            <div class="col-lg-4">
                <h2 class="page-header">Timeline</h2>
                <a class="twitter-timeline" href="https://twitter.com/a_c_h_r" data-widget-id="625899581000146945">Tweets by </a>
                <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");
                </script>
            </div>
            
        </div>
        <!-- /.row -->
        
        
        
        
        
      
        <!-- Controls -->
        <script>
        $('.carousel').carousel({
            interval: 5000 //changes the speed
        })
        </script>
  

     